# RustBlockingQueue

https://JimFawcett.github.io/RustBlockingQueue.html

Thread safe queue that blocks dequeuer when empty
